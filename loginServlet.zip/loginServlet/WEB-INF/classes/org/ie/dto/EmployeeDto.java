package org.ie.dto;

public class EmployeeDto {
    private int id;
    private String EmployeeName;
    private String Address;
    private String designation;
    private String userName;
    private String passWord;

    public void setId(int id) {
        this.id = id;
    }

    public void setEmployeeName(String employeeName) {
        EmployeeName = employeeName;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public int getId() {
        return id;
    }

    public String getEmployeeName() {
        return EmployeeName;
    }

    public String getAddress() {
        return Address;
    }

    public String getDesignation() {
        return designation;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassWord() {
        return passWord;
    }
}
