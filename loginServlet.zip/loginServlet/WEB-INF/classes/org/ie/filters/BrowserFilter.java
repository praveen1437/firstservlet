package org.ie.filters;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.PrintWriter;

public class BrowserFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain filterChain) throws IOException, ServletException {
      //  String agent= (String) req.getAttribute("user-agent");
        PrintWriter pw;
        pw=res.getWriter();
        res.setContentType("text/html");
        String agent= ((HttpServletRequest)req).getHeader("user-agent");
        System.out.println(agent);
        if(agent.indexOf("chrome")==-1){
            pw.println("Please use google chrome browser");
        }
        else {
            filterChain.doFilter(req, res);
            // if(agent.indexOf(
        }
    }

    @Override
    public void destroy() {

    }
}
