package org.ie.filters;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import java.io.IOException;

public class BrowserFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain filterChain) throws IOException, ServletException {
        String agent= (String) req.getAttribute("user-agent");

    }

    @Override
    public void destroy() {

    }
}
