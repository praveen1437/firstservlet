package org.ie.dao;

import org.ie.dto.EmployeeDto;

import java.sql.*;

public class JdbcLogic {
    private final static String CHECK_QUERY = "SELECT PASSWORD FROM EMPDETAILS WHERE USERNAME=?";
    private final static String INSERT_QUERY = "INSERT INTO EMPDETAILS (PERSONID,NAME,ADDRESS,DESIGNATION,USERNAME,PASSWORD) VALUES(?,?,?,?,?,?)";
    private final static String USER_CHECK = "SELECT USERNAME FROM EMPDETAILS WHERE USERNAME=?";
    private final static String FETCH_DATA= "SELECT * FROM EMPDETAILS WHERE USERNAME=?";
    /*public static void main(String[] args) {
        boolean b = false;
        try {
            b = checkCredentials("naruto", "uzumaki");
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
        if (b) {
            System.out.println("u r logged in successfully");
        } else {
            System.out.println("login failed");
        }
    }*/

    public static boolean checkCredentials(String user, String password) throws SQLException, ClassNotFoundException {
        PreparedStatement ps;
        ResultSet rs;
        String pwd = "notfound";
        Class.forName("com.mysql.jdbc.Driver");
        try (Connection con = DriverManager.getConnection("jdbc:mysql://iedevdb.cju8h0qbqt75.ap-south-1.rds.amazonaws.com:3306/training", "dbadmin", "dbadmin123")) {
            ps = con.prepareStatement(CHECK_QUERY);
            ps.setString(1, user);
            rs = ps.executeQuery();
            while (rs.next()) {
                pwd = rs.getString(1);
                System.out.println(pwd);
            }
            if (pwd.equals("notfound")) {
                throw new IllegalArgumentException("wrong user name");
            }
            return pwd.equals(password);
        }
    }

    public boolean insertData(EmployeeDto dto) throws SQLException, ClassNotFoundException {
        PreparedStatement ps1, ps2;
        ResultSet rs;
        int count = 0;
        //createConnection
        Class.forName("com.mysql.jdbc.Driver");
        try (Connection con = DriverManager.getConnection("jdbc:mysql://iedevdb.cju8h0qbqt75.ap-south-1.rds.amazonaws.com:3306/training", "dbadmin", "dbadmin123")) {
          //prepare statemnt object creation
            ps1 = con.prepareStatement(USER_CHECK);
            //execute the query
            ps1.setString(1,dto.getUserName());
            rs = ps1.executeQuery();
            String username = "notfound";
            //process the result for username checking
            while (rs.next()) {
                username = rs.getString(1);
            }
            if (!username.equals("notfound")) {
                throw new IllegalArgumentException("user name  already exits please choose another one");
            }
            //add new user to the database
            ps2 = con.prepareStatement(INSERT_QUERY);
            ps2.setInt(1, dto.getId());
            ps2.setString(2, dto.getEmployeeName());
            ps2.setString(3, dto.getAddress());
            ps2.setString(4, dto.getDesignation());
            ps2.setString(5, dto.getUserName());
            ps2.setString(6, dto.getPassWord());
            count = ps2.executeUpdate();
            System.out.println(count);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return count != 0;
    }
    public EmployeeDto fetchEmpDetails(String user) throws SQLException {
        PreparedStatement preparedStatement;
        ResultSet resultSet;
        EmployeeDto employee=null;
        try (Connection con = DriverManager.getConnection("jdbc:mysql://iedevdb.cju8h0qbqt75.ap-south-1.rds.amazonaws.com:3306/training", "dbadmin", "dbadmin123")) {
            preparedStatement= con.prepareStatement(FETCH_DATA);
            preparedStatement.setString(1,user);
            resultSet= preparedStatement.executeQuery();
            //process the resultset
            while(resultSet.next()){
                employee=new EmployeeDto();
                employee.setId(resultSet.getInt(1));
                employee.setEmployeeName(resultSet.getString(2));
                employee.setAddress(resultSet.getString(3));
                employee.setDesignation(resultSet.getString(4));
                employee.setUserName(resultSet.getString(5));
                employee.setPassWord(resultSet.getString(6));
            }

        }
        return employee;
    }
}
