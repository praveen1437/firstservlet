package org.ie.servlets;

import org.ie.dao.JdbcLogic;
import org.ie.dto.EmployeeDto;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

public class SignUpServlet extends HttpServlet {
    JdbcLogic jl= new JdbcLogic();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        PrintWriter pw;
        pw= res.getWriter();
        //get the values from singup html
        String id= req.getParameter("sId");
        String name= req.getParameter("sName");
        String address= req.getParameter("sAddress");
        String designation= req.getParameter("sDesignation");
        String userName= req.getParameter("sUserName");
        String passWord= req.getParameter("sPwd");
     // set values into employee dto object
        EmployeeDto newEmployee= new EmployeeDto();
        newEmployee.setId(Integer.parseInt(id));
        newEmployee.setEmployeeName(name);
        newEmployee.setDesignation(designation);
        newEmployee.setAddress(address);
        newEmployee.setUserName(userName);
        newEmployee.setPassWord(passWord);

        try {
            jl.insertData(newEmployee);
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }
}
