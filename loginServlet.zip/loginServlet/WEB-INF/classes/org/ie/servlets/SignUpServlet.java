package org.ie.servlets;

import org.ie.dao.JdbcLogic;
import org.ie.dto.EmployeeDto;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
public class SignUpServlet extends HttpServlet {
    JdbcLogic jl= new JdbcLogic();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        PrintWriter pw;
        pw= res.getWriter();
        boolean b=false;
        //get the values from singup html
        String id= req.getParameter("sId");
        String name= req.getParameter("sname");
        String address= req.getParameter("sAddress");
        String designation= req.getParameter("sDesignation");
        String userName= req.getParameter("un");
        String passWord= req.getParameter("sPwd");
     // set values into employee dto object
        System.out.println("name = " + name);
        System.out.println("userName = " + userName);
        System.out.println("passWord = " + passWord);

        EmployeeDto newEmployee= new EmployeeDto();
        newEmployee.setId(Integer.parseInt(id));
        newEmployee.setEmployeeName(name);
        newEmployee.setDesignation(designation);
        newEmployee.setAddress(address);
        newEmployee.setUserName(userName);
        newEmployee.setPassWord(passWord);

        try {
           b= jl.insertData(newEmployee);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        catch (IllegalArgumentException e){
            pw.println("<h1>"+e.getMessage()+"</h1>");

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        if(b){
           pw.println("<h1> Registered Successfully</h1>");
       }
       else{
           pw.println("<h1> Registration failed</h1>");
       }
        pw.println("<a href=Login.html>HOME</a>");
       pw.println("<a href=signup.html>Signup</a>");

    }
}
