package org.ie.servlets;

import org.ie.dao.JdbcLogic;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

@WebServlet("/login")
public class LoginCheck extends HttpServlet {
    private JdbcLogic jl= new JdbcLogic();
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        PrintWriter pw;
        boolean b=false;
        pw=res.getWriter();
        res.setContentType("text/html");
        String user=req.getParameter("user");
        String pwd= req.getParameter("pwd");
        try {
            b=jl.checkCredentials(user,pwd);
        } catch (SQLException e) {
            e.printStackTrace();
        }
      if(b){
          pw.println("<h1>you are logged in successfully</h1>");
      }
      else{
          pw.println("<h1> login failed. invalid credentials</h1>");
      }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
